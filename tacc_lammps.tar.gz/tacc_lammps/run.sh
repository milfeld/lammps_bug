ibrun ./lmp_stampede -sf intel -in in.spce 2>&1 | tee log_2.mem

mpirun_rsh  -np 16 -hostfile hostfile ./lmp_stampede -sf intel -in in.spce 

usage: mpirun_rsh [-v] [-sg group] [-rsh|-ssh] [-debug] -[tv] [-xterm] [-show] [-legacy] [-export|-export-all] -np N (-hostfile hfile | h1 h2 ... hN) a.out args | -config configfile (-hostfile hfile | h1 h2 ... hN)]


ibrun -np 1 valgrind --tool=memcheck --leak-check=yes --error-limit=no --leak-check=full --show-reachable=yes ./lmp_stampede -sf intel -in in.spce 2>&1 | tee log_2.mem

